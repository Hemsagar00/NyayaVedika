(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))o(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const p of c.addedNodes)p.tagName==="LINK"&&p.rel==="modulepreload"&&o(p)}).observe(document,{childList:!0,subtree:!0});function a(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function o(l){if(l.ep)return;l.ep=!0;const c=a(l);fetch(l.href,c)}})();const fe={lmstudio:{url:"http://192.168.1.11:1234/v1/chat/completions",model:"google/gemma-4-e4b",getKey:()=>"lm-studio"},nvidia:{url:"https://integrate.api.nvidia.com/v1/chat/completions",model:"meta/llama-3.1-70b-instruct",getKey:()=>{}},deepseek:{url:"https://api.deepseek.com/v1/chat/completions",model:"deepseek-chat",getKey:()=>{}},anthropic:{url:"https://api.anthropic.com/v1/messages",model:"claude-3-5-sonnet-20241022",getKey:()=>{}},gemini:{url:"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",getKey:()=>{}},ollama:{url:"http://localhost:11434/v1/chat/completions",model:"gemma4:latest",getKey:()=>"ollama-local"},friday:{url:"/api/friday",getKey:()=>"friday-bridge"}},x="nvidia";let B=null;function de(){B&&(B.abort(),B=null)}const be=`You are NyayaVedika AI, an expert legal drafting assistant for Indian advocates. You are an indispensable AI tool for legal research, drafting, and legal practice.

CORE EXPERTISE:
- Bharatiya Nyaya Sanhita (BNS, 2023) — replaces IPC
- Bharatiya Nagarik Suraksha Sanhita (BNSS, 2023) — replaces CrPC
- Bharatiya Sakshya Adhiniyam (BSA, 2023) — replaces Indian Evidence Act
- IPC / CrPC / IEA — cross-references for transitional cases
- Constitutional law (Articles 14, 19, 21, 32, 136, 226, 227, 300A)
- NDPS Act — Section 37 twin conditions for bail (mandatory satisfaction: (a) reasonable grounds for believing not guilty, AND (b) not likely to commit offence while on bail). Key precedents: Narcotics Control Bureau v. Kishan Lal (2019), Tofan Singh v. State of Tamil Nadu (2020)
- Revenue laws of Andhra Pradesh & Telangana (ROR, mutations, 1-B proceedings)
- Consumer Protection Act, 2019
- NI Act Section 138 (cheque bounce), IBC/CIRP, DV Act

QUASHING PETITIONS:
- Section 528 BNSS (replaces Section 482 CrPC) — inherent powers of High Court
- Section 261 BNSS (replaces Section 239 CrPC) — discharge provisions

FORMATTING:
- Use proper cause title format (Indian court style)
- Include Synopsis and List of Dates for SC/HC petitions
- Number all grounds with statutory citations
- Include verification affidavit format
- Generate prayer clause with specific reliefs
- Cite both old (IPC/CrPC) and new (BNS/BNSS) provisions where relevant

COURTS COVERED: Supreme Court of India, all 25 High Courts, District & Sessions Courts, Magistrate Courts, Revenue authorities (Tahsildar/RDO/Joint Collector), NCLT/NCLAT, NCDRC, ITAT, CAT, NGT, RERA, DRT, SAT, CESTAT.

Always provide accurate, well-structured legal content. Cite relevant provisions and precedents. Never fabricate case law.`;async function E(e,t={}){var p,g,f,A;const{maxTokens:a=4096,temperature:o=.4}=t,l=fe[x];if(!l)throw new Error(`Unknown AI provider: ${x}`);const c=l.getKey();if(!c&&x!=="friday")throw new Error(`API key not configured. Please set VITE_${x.toUpperCase()}_API_KEY in your Vercel environment variables.`);de(),B=new AbortController;try{const b=await fetch(l.url,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${c}`},body:JSON.stringify({model:l.model,messages:[{role:"system",content:be},{role:"user",content:e}],max_tokens:a,temperature:o,stream:!1}),signal:B.signal});if(!b.ok){const h=await b.json().catch(()=>({}));throw new Error(((p=h.error)==null?void 0:p.message)||`API Error: ${b.status}`)}return((A=(f=(g=(await b.json()).choices)==null?void 0:g[0])==null?void 0:f.message)==null?void 0:A.content)||""}finally{B=null}}async function we(e){const{docType:t,court:a,petitioner:o,respondent:l,facts:c,reliefSought:p}=e;return E(`Draft a complete ${t} for filing before the ${a}.

PARTIES:
- Petitioner/Applicant: ${o}
- Respondent/Opposite Party: ${l||"State / Authority"}

FACTS OF THE CASE:
${c}

RELIEF SOUGHT:
${p||"As per the nature of the petition"}

REQUIREMENTS:
1. Proper cause title with court header
2. Synopsis and List of Dates (for SC/HC petitions)
3. Numbered grounds with statutory citations (cite both BNS/BNSS and IPC/CrPC where applicable)
4. Prayer clause with specific reliefs
5. Verification / Affidavit format
6. All formatting per ${a} Rules`,{maxTokens:4096})}async function Ce(e){return E(`Explain the following legal clause in plain English, noting its significance under Indian law:

"${e}"`,{maxTokens:512})}async function Se(e,t){return E(`Suggest the strongest legal grounds for a ${e} based on the following facts. For each ground, cite specific statutory provisions (BNS/BNSS and IPC/CrPC cross-references) and relevant Supreme Court / High Court precedents:

${t}`,{maxTokens:2048})}async function Ie(e){return E(`Summarize the following legal document. Identify:
1. Parties involved
2. Key dates and timeline
3. Core legal issues
4. Orders / Holdings
5. Important deadlines or next steps

${e}`,{maxTokens:1024})}async function Ee(e){return E(`Answer the following legal question with detailed analysis under Indian law. Cite relevant statutes (BNS/BNSS/IPC/CrPC/Constitution), Supreme Court and High Court precedents, and practical guidance:

${e}`,{maxTokens:2048})}async function Ae(e){return E(`Perform a comprehensive analysis of the following case material (FIR/chargesheet/judgment/order). Provide:

1. **Parties** — Names, designations, roles
2. **Facts** — Timeline of events
3. **Legal Issues** — Key questions of law
4. **Applicable Statutes** — BNS/BNSS/IPC/CrPC sections and special acts
5. **Relevant Precedents** — Supreme Court and High Court cases on similar issues
6. **Strategic Notes** — Strengths, weaknesses, and recommended approach
7. **Next Steps** — Filing deadlines, limitation periods, interim reliefs available

CASE MATERIAL:
${e}`,{maxTokens:4096})}async function xe(e,t=""){const a=t?`

SPECIFIC CASE FACTS:
${t}`:"";return E(`Find and explain the most relevant Supreme Court and High Court precedents on the following legal topic/issue under Indian law. For each case, provide:

1. **Case Name & Citation** (with year and court)
2. **Key Legal Principle** established
3. **Relevant Facts** that make it applicable
4. **How it can be cited** in arguments

LEGAL TOPIC/ISSUE: ${e}${a}

Provide at least 5-8 relevant precedents, prioritizing Supreme Court decisions.`,{maxTokens:4096})}async function ke(e){return E(`Generate a comprehensive legal update / digest on the following topic under Indian law:

TOPIC: ${e}

Provide:
1. **Overview** — Current state of the law on this topic
2. **Key Statutes** — All relevant provisions (BNS, BNSS, BSA, special acts)
3. **Landmark Judgments** — Supreme Court and High Court decisions with citations and holdings
4. **Recent Developments** — Latest amendments, circulars, notifications
5. **Practice Tips** — Practical guidance for advocates handling such cases
6. **Common Pitfalls** — Mistakes to avoid

Make it comprehensive and cite specific sections, rules, and case law.`,{maxTokens:4096})}async function Te(e){return E(`Generate 5 notable recent legal developments and important judgments for the category: "${e}" in Indian courts.

For each item, provide:
- A headline/title (first line)
- A 2-3 sentence summary with the key legal principle, parties, and practical impact

Separate each item with "|||" (three pipe characters). Do NOT use any other separator.

Focus on real, well-known legal principles and landmark cases. Cover diverse topics within ${e}.`,{maxTokens:2048,temperature:.6})}const y={history:"nv_draft_history",snippets:"nv_snippets",favorites:"nv_favorites",theme:"nv_theme",chatHistory:"nv_chat_history"};function H(){try{return JSON.parse(localStorage.getItem(y.history))||[]}catch{return[]}}function Be(e){const t=H();return t.unshift({id:Date.now(),title:e.title||"Untitled Draft",type:e.type||"",court:e.court||"",content:e.content||"",timestamp:new Date().toISOString()}),t.length>50&&(t.length=50),localStorage.setItem(y.history,JSON.stringify(t)),t}function Ne(e){const t=H().filter(a=>a.id!==e);return localStorage.setItem(y.history,JSON.stringify(t)),t}function R(){try{return JSON.parse(localStorage.getItem(y.snippets))||[]}catch{return[]}}function Le(e){const t=R();return t.unshift({id:Date.now(),title:e.title||"Untitled Snippet",content:e.content||"",category:e.category||"General",timestamp:new Date().toISOString()}),localStorage.setItem(y.snippets,JSON.stringify(t)),t}function Pe(e){const t=R().filter(a=>a.id!==e);return localStorage.setItem(y.snippets,JSON.stringify(t)),t}function q(){try{return JSON.parse(localStorage.getItem(y.favorites))||[]}catch{return[]}}function De(e){let t=q();const a=t.indexOf(e);return a>=0?t.splice(a,1):(t.push(e),t.length>8&&t.shift()),localStorage.setItem(y.favorites,JSON.stringify(t)),t}function O(){return localStorage.getItem(y.theme)||"dark"}function ue(e){localStorage.setItem(y.theme,e),document.documentElement.setAttribute("data-theme",e)}function pe(){const t=O()==="dark"?"light":"dark";return ue(t),t}function me(){try{return JSON.parse(localStorage.getItem(y.chatHistory))||[]}catch{return[]}}function re(e,t){const a=me();return a.push({role:e,content:t,timestamp:Date.now()}),a.length>100&&a.splice(0,a.length-100),localStorage.setItem(y.chatHistory,JSON.stringify(a)),a}function He(){localStorage.removeItem(y.chatHistory)}function Re(e,t){const a=new Blob([e],{type:"text/plain;charset=utf-8"});ve(a,`${t}.txt`)}function $e(e,t){const a=`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style>
    body { font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 2.0;
           max-width: 7.5in; margin: 1in auto; padding: 20px; color: #000; }
    p { margin: 6pt 0; }
    h1 { font-size: 16pt; font-weight: bold; text-align: center; margin-bottom: 24pt; }
    h2 { font-size: 14pt; font-weight: bold; margin-top: 18pt; }
    h3 { font-size: 12pt; font-weight: bold; margin-top: 12pt; }
    pre { font-family: 'Times New Roman', serif; white-space: pre-wrap; line-height: 2.0; }
    .numbered { margin-left: 36pt; }
    @media print { body { margin: 0; } }
  </style>
</head>
<body>
<pre>${Oe(e)}</pre>
</body>
</html>`,o=new Blob([a],{type:"application/msword;charset=utf-8"});ve(o,`${t}.doc`)}function F(e,t,a){const o=a||`nyayavedika-draft-${Date.now()}`;switch(t){case"doc":return $e(e,o);case"txt":default:return Re(e,o)}}function ve(e,t){const a=URL.createObjectURL(e),o=document.createElement("a");o.href=a,o.download=t,document.body.appendChild(o),o.click(),document.body.removeChild(o),setTimeout(()=>URL.revokeObjectURL(a),1e3)}function Oe(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}function w(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}const le=["Bail Application","Anticipatory Bail Application","NDPS Bail Application (Section 37)","Default Bail Application (Section 187 BNSS / 167 CrPC)","Writ Petition (Article 226)","Writ Petition (Article 32)","Special Leave Petition (SLP)","Revenue Appeal","Civil Suit","Criminal Revision Petition","Quashing Petition (Section 528 BNSS / 482 CrPC)","Execution Petition","Mutation Application","Interlocutory Application (IA)","Contempt Petition","Legal Notice (Demand / Eviction / Breach)","Reply to Legal Notice","Written Submission / Written Arguments","PIL (Public Interest Litigation)","Habeas Corpus Petition","Consumer Complaint","Cheque Bounce Complaint (NI Act 138)","Divorce Petition","DV Act Application","Rent Control Application"],Fe=["Supreme Court of India","High Court of Andhra Pradesh","High Court of Telangana","Allahabad High Court","Bombay High Court","Calcutta High Court","Chhattisgarh High Court","Delhi High Court","Gauhati High Court","Gujarat High Court","Himachal Pradesh High Court","Jammu & Kashmir High Court","Jharkhand High Court","Karnataka High Court","Kerala High Court","Madhya Pradesh High Court","Madras High Court","Manipur High Court","Meghalaya High Court","Nagpur Bench (Bombay HC)","Orissa High Court","Patna High Court","Punjab & Haryana High Court","Rajasthan High Court","Sikkim High Court","Tripura High Court","Uttarakhand High Court","District & Sessions Court","Civil Judge (Senior Division)","First Class Judicial Magistrate","Metropolitan Magistrate Court","Revenue Divisional Officer (RDO)","Tahsildar Office","Joint Collector","National Consumer Disputes Redressal Commission (NCDRC)","State Consumer Disputes Redressal Commission","District Consumer Forum","National Company Law Tribunal (NCLT)","National Company Law Appellate Tribunal (NCLAT)","Income Tax Appellate Tribunal (ITAT)","Central Administrative Tribunal (CAT)","National Green Tribunal (NGT)","Real Estate Regulatory Authority (RERA)","Debt Recovery Tribunal (DRT)","SEBI - Securities Appellate Tribunal (SAT)","Customs Excise & Service Tax Appellate Tribunal (CESTAT)"];function ze(e){const t=document.getElementById(e);t&&(t.innerHTML=qe(),Ge(t))}function qe(){return`
<div class="drafting-layout">
  <div class="drafting-main">
    <div class="scrolling-ticker-wrap">
      <span class="ticker-badge">🔴 LIVE BREAKING</span>
      <div class="scrolling-ticker" id="news-ticker"><div class="ticker-track">Fetching latest legal updates and breaking court news...</div></div>
    </div>

    <div class="ai-panel" id="ai-drafting-panel">
      <div class="ai-panel-header">
        <span class="ai-panel-icon">◈</span>
        <div>
          <h2 class="ai-panel-title">NyayaVedika AI</h2>
          <p class="ai-panel-sub">AI-powered legal drafting, research & analysis</p>
        </div>
        <span class="ai-status" id="ai-status-indicator">
          <span class="status-dot"></span> Ready
        </span>
      </div>

  <div class="ai-tabs" role="tablist" aria-label="AI tools" id="ai-tabs">
    <button class="ai-tab active" data-tab="ask" role="tab" aria-selected="true" aria-controls="tab-ask" id="tab-btn-ask">💬 Ask AI</button>
    <button class="ai-tab" data-tab="draft" role="tab" aria-selected="false" aria-controls="tab-draft" id="tab-btn-draft">📄 Draft</button>
    <button class="ai-tab" data-tab="caselaws" role="tab" aria-selected="false" aria-controls="tab-caselaws" id="tab-btn-caselaws">🔍 Case Laws</button>
    <button class="ai-tab" data-tab="analyze" role="tab" aria-selected="false" aria-controls="tab-analyze" id="tab-btn-analyze">📋 Analyze</button>
    <button class="ai-tab" data-tab="grounds" role="tab" aria-selected="false" aria-controls="tab-grounds" id="tab-btn-grounds">⚖️ Grounds</button>
    <button class="ai-tab" data-tab="summarize" role="tab" aria-selected="false" aria-controls="tab-summarize" id="tab-btn-summarize">📑 Summarize</button>
    <button class="ai-tab" data-tab="explain" role="tab" aria-selected="false" aria-controls="tab-explain" id="tab-btn-explain">💡 Explain</button>
  </div>

  <!-- Favorites Quick-Access Bar -->
  <div class="favorites-bar" id="favorites-bar" style="display:none">
    <span class="favorites-label">⭐ Quick Access:</span>
    <div class="favorites-list" id="favorites-list"></div>
  </div>

  <!-- TAB: Ask AI (Chat-style) -->
  <div class="ai-tab-content active" id="tab-ask" role="tabpanel" aria-labelledby="tab-btn-ask">
    <div class="chat-container" id="chat-container">
      <div class="chat-messages" id="chat-messages">
        <div class="chat-msg assistant">
          <div class="chat-avatar">◈</div>
          <div class="chat-bubble">
            <p>Welcome to NyayaVedika AI. Ask me any legal question — I'll provide detailed answers with relevant statutes, case law, and practical guidance under Indian law.</p>
            <p class="chat-hint">Try: <em>"What are the twin conditions for bail under Section 37 NDPS Act?"</em> or <em>"Explain Article 226 vs 227"</em></p>
          </div>
        </div>
      </div>
      <div class="chat-input-area">
        <textarea class="chat-input" id="chat-input" rows="2" placeholder="Ask a legal question..." aria-label="Type your legal question"></textarea>
        <div class="chat-actions">
          <button class="btn btn-outline btn-sm" id="btn-chat-clear" title="Clear chat">Clear</button>
          <button class="btn btn-primary btn-sm" id="btn-chat-send">
            <span class="btn-icon">💬</span> Send <small>(Ctrl+Enter)</small>
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- TAB: Draft Document -->
  <div class="ai-tab-content" id="tab-draft" role="tabpanel" aria-labelledby="tab-btn-draft">
    <div class="form-grid">
      <div class="form-group">
        <label class="form-label">Document Type</label>
        <select class="form-select" id="doc-type">
          <option value="">— Select —</option>
          ${le.map(e=>`<option value="${e}">${e}</option>`).join("")}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Court / Authority</label>
        <select class="form-select" id="court-name">
          <option value="">— Select —</option>
          ${Fe.map(e=>`<option value="${e}">${e}</option>`).join("")}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Petitioner / Applicant</label>
        <input class="form-input" id="petitioner" placeholder="Full name, age, address" />
      </div>
      <div class="form-group">
        <label class="form-label">Respondent / Opposite Party</label>
        <input class="form-input" id="respondent" placeholder="Name, designation or authority" />
      </div>
    </div>
    <div class="form-group mt-16">
      <label class="form-label">Facts of the Case</label>
      <textarea class="form-textarea" id="facts" rows="5" placeholder="Describe the background facts, incident, dates, and relevant details..."></textarea>
    </div>
    <div class="form-group mt-16">
      <label class="form-label">Relief Sought</label>
      <textarea class="form-textarea" id="relief" rows="3" placeholder="What relief or order do you want the court to pass?"></textarea>
    </div>
    <button class="btn btn-primary btn-block mt-20" id="btn-draft">
      <span class="btn-icon">⚡</span> Generate Draft
    </button>
  </div>

  <!-- TAB: Find Case Laws -->
  <div class="ai-tab-content" id="tab-caselaws" role="tabpanel" aria-labelledby="tab-btn-caselaws">
    <div class="ask-ai-intro">
      <p>Enter a legal topic or issue — AI will find and explain the most relevant Supreme Court & High Court precedents.</p>
    </div>
    <div class="form-group">
      <label class="form-label">Legal Topic / Issue</label>
      <input class="form-input" id="caselaws-topic" placeholder="e.g. Section 37 NDPS Act twin conditions for bail" />
    </div>
    <div class="form-group mt-16">
      <label class="form-label">Case Facts (optional)</label>
      <textarea class="form-textarea" id="caselaws-facts" rows="4" placeholder="Add your specific case facts for more relevant results..."></textarea>
    </div>
    <button class="btn btn-primary btn-block mt-20" id="btn-caselaws">
      <span class="btn-icon">🔍</span> Find Relevant Case Laws
    </button>
  </div>

  <!-- TAB: Analyze Case -->
  <div class="ai-tab-content" id="tab-analyze" role="tabpanel" aria-labelledby="tab-btn-analyze">
    <div class="ask-ai-intro">
      <p>Paste any case material — chargesheet, judgment, FIR, order — and get a comprehensive AI analysis with parties, issues, applicable law, and strategy.</p>
    </div>
    <div class="form-group">
      <label class="form-label">Paste Case Material</label>
      <textarea class="form-textarea" id="analyze-text" rows="10" placeholder="Paste the full text of an FIR, chargesheet, judgment, court order, or any case document..."></textarea>
    </div>
    <button class="btn btn-primary btn-block mt-20" id="btn-analyze">
      <span class="btn-icon">📋</span> Analyze Case
    </button>
  </div>

  <!-- TAB: Suggest Grounds -->
  <div class="ai-tab-content" id="tab-grounds" role="tabpanel" aria-labelledby="tab-btn-grounds">
    <div class="form-group">
      <label class="form-label">Document Type</label>
      <select class="form-select" id="grounds-doc-type">
        <option value="">— Select —</option>
        ${le.map(e=>`<option value="${e}">${e}</option>`).join("")}
      </select>
    </div>
    <div class="form-group mt-16">
      <label class="form-label">Facts of the Case</label>
      <textarea class="form-textarea" id="grounds-facts" rows="6" placeholder="Describe your client's situation and relevant background..."></textarea>
    </div>
    <button class="btn btn-primary btn-block mt-20" id="btn-grounds">
      <span class="btn-icon">⚖️</span> Suggest Legal Grounds
    </button>
  </div>

  <!-- TAB: Summarize -->
  <div class="ai-tab-content" id="tab-summarize" role="tabpanel" aria-labelledby="tab-btn-summarize">
    <div class="form-group">
      <label class="form-label">Paste Document Text</label>
      <textarea class="form-textarea" id="summary-text" rows="10" placeholder="Paste the text of a judgment, order, deed, or any legal document..."></textarea>
    </div>
    <button class="btn btn-primary btn-block mt-20" id="btn-summarize">
      <span class="btn-icon">📑</span> Summarize Document
    </button>
  </div>

  <!-- TAB: Explain Clause -->
  <div class="ai-tab-content" id="tab-explain" role="tabpanel" aria-labelledby="tab-btn-explain">
    <div class="form-group">
      <label class="form-label">Paste Clause or Legal Text</label>
      <textarea class="form-textarea" id="clause-text" rows="6" placeholder="Paste a specific clause, section, or legal provision to get a plain-English explanation..."></textarea>
    </div>
    <button class="btn btn-primary btn-block mt-20" id="btn-explain">
      <span class="btn-icon">💡</span> Explain This Clause
    </button>
  </div>

  <!-- OUTPUT AREA -->
  <div class="ai-output" id="ai-output" style="display:none">
    <div class="output-header">
      <span class="output-title">Generated Output</span>
      <div class="output-actions">
        <button class="btn btn-outline btn-sm" id="btn-copy">Copy</button>
        <button class="btn btn-outline btn-sm" id="btn-download-txt">Save .txt</button>
        <button class="btn btn-outline btn-sm" id="btn-download-doc">Save .doc</button>
        <button class="btn btn-outline btn-sm" id="btn-download-docx">Save .docx</button>
        <button class="btn btn-outline btn-sm" id="btn-save-snippet" title="Save as snippet">☆ Save</button>
        <button class="btn btn-outline btn-sm" id="btn-clear">Clear</button>
      </div>
    </div>
    <div class="output-body" id="output-body"></div>
  </div>

  <!-- ERROR STATE -->
  <div class="ai-error" id="ai-error" style="display:none" role="alert">
    <span class="error-icon">&#x26A0;&#xFE0F;</span>
    <p class="error-text" id="error-text"></p>
  </div>

  <!-- LOADING STATE -->
  <div class="ai-loading" id="ai-loading" style="display:none" role="status" aria-live="polite">
    <div class="loading-spinner" aria-hidden="true"></div>
    <p class="loading-text" id="loading-text">Generating draft...</p>
    <button class="btn btn-outline btn-sm" id="btn-cancel">Cancel</button>
  </div>

  <!-- SNIPPETS MODAL -->
  <div class="snippets-panel" id="snippets-panel" style="display:none">
    <div class="snippets-header">
      <h3>📋 Saved Snippets</h3>
      <button class="btn btn-outline btn-sm" id="btn-snippets-close">✕</button>
    </div>
    <div class="snippets-list" id="snippets-list">
      <p class="snippets-empty">No snippets saved yet. Save generated outputs or frequently used text as snippets for quick reuse.</p>
    </div>
  </div>

  <!-- HISTORY PANEL -->
  <div class="history-panel" id="history-panel" style="display:none">
    <div class="history-header">
      <h3>📜 Draft History</h3>
      <button class="btn btn-outline btn-sm" id="btn-history-close">✕</button>
    </div>
    <div class="history-list" id="history-list">
      <p class="history-empty">No drafts generated yet. Your generated documents will appear here.</p>
    </div>
  </div>

  </div>
    </div> <!-- end ai-panel -->
    <div class="panel-side-actions">
      <button class="btn btn-outline btn-sm" id="btn-show-history" title="Draft History">📜 History</button>
      <button class="btn btn-outline btn-sm" id="btn-show-snippets" title="Saved Snippets">📋 Snippets</button>
    </div>
  </div> <!-- end drafting-main -->

  <div class="live-widget-sidebar">
    <div class="widget-header">
      <h3>Latest Judgments</h3>
      <span class="live-pulse"></span>
    </div>
    <div class="widget-tabs" id="widget-tabs">
      <button class="widget-tab active" data-wtab="Supreme Court">SC News</button>
      <button class="widget-tab" data-wtab="High Court">HC News</button>
      <button class="widget-tab" data-wtab="Tribunals">Tribunals</button>
    </div>
    <div class="widget-content" id="widget-news-content">
      <div class="widget-loading" id="widget-loading">
        <div class="loading-spinner"></div>
        <p>Fetching live feed...</p>
      </div>
      <div class="widget-feed" id="widget-feed" style="display:none;"></div>
      <div class="widget-error" id="widget-error" style="display:none; color: var(--amber); font-size: 0.85rem; padding: 10px;"></div>
    </div>
  </div> <!-- end sidebar -->
</div> <!-- end drafting-layout -->`}function Ge(e){var v,h,N,k,M,K,J,W,_,Y,Q,X,Z,ee,te,ae,ne,ie,se;e.querySelectorAll(".ai-tab").forEach(n=>{n.addEventListener("click",()=>{var i;e.querySelectorAll(".ai-tab").forEach(r=>{r.classList.remove("active"),r.setAttribute("aria-selected","false")}),e.querySelectorAll(".ai-tab-content").forEach(r=>r.classList.remove("active")),n.classList.add("active"),n.setAttribute("aria-selected","true");const s=`tab-${n.dataset.tab}`;(i=document.getElementById(s))==null||i.classList.add("active"),U(),V()})});function t(n,s){const i=document.getElementById("chat-messages");if(!i)return;const r=n==="user",d=document.createElement("div");d.className=`chat-msg ${n}`,d.innerHTML=r?`<div class="chat-bubble user-bubble">${w(s)}</div><div class="chat-avatar user-avatar">👤</div>`:`<div class="chat-avatar">◈</div><div class="chat-bubble">${s.replace(/\n/g,"<br>")}</div>`,i.appendChild(d),i.scrollTop=i.scrollHeight}function a(){const n=document.getElementById("chat-messages");if(!n)return;const s=me();if(n.innerHTML="",s.length===0){n.innerHTML=`<div class="chat-msg assistant">
        <div class="chat-avatar">◈</div>
        <div class="chat-bubble">
          <p>Welcome to NyayaVedika AI. Ask me any legal question — I'll provide detailed answers with relevant statutes, case law, and practical guidance under Indian law.</p>
          <p class="chat-hint">Try: <em>"What are the twin conditions for bail under Section 37 NDPS Act?"</em> or <em>"Explain Article 226 vs 227"</em></p>
        </div>
      </div>`;return}s.forEach(i=>t(i.role,i.content))}async function o(){var i;const n=document.getElementById("chat-input"),s=(i=n==null?void 0:n.value)==null?void 0:i.trim();if(s){n.value="",t("user",s),re("user",s),V(),he("Analyzing...");try{const r=await Ee(s);L(),t("assistant",r),re("assistant",r)}catch(r){L(),I(r.message)}}}(v=document.getElementById("btn-chat-send"))==null||v.addEventListener("click",o),(h=document.getElementById("btn-chat-clear"))==null||h.addEventListener("click",()=>{He(),a()}),a(),(N=document.getElementById("btn-draft"))==null||N.addEventListener("click",async()=>{var s,i,r,d,m,C;const n={docType:(s=document.getElementById("doc-type"))==null?void 0:s.value,court:(i=document.getElementById("court-name"))==null?void 0:i.value,petitioner:(r=document.getElementById("petitioner"))==null?void 0:r.value,respondent:(d=document.getElementById("respondent"))==null?void 0:d.value,facts:(m=document.getElementById("facts"))==null?void 0:m.value,reliefSought:(C=document.getElementById("relief"))==null?void 0:C.value};if(!n.docType||!n.court||!n.petitioner||!n.facts){I("Please fill in Document Type, Court, Petitioner, and Facts.");return}await T("Generating draft petition...",()=>we(n),{title:`${n.docType} — ${n.petitioner}`,type:n.docType,court:n.court})}),(k=document.getElementById("btn-caselaws"))==null||k.addEventListener("click",async()=>{var i,r;const n=(i=document.getElementById("caselaws-topic"))==null?void 0:i.value,s=(r=document.getElementById("caselaws-facts"))==null?void 0:r.value;if(!n){I("Please enter a legal topic or issue.");return}await T("Searching for relevant case laws...",()=>xe(n,s))}),(M=document.getElementById("btn-analyze"))==null||M.addEventListener("click",async()=>{var s;const n=(s=document.getElementById("analyze-text"))==null?void 0:s.value;if(!n){I("Please paste case material to analyze.");return}await T("Analyzing case material...",()=>Ae(n))}),(K=document.getElementById("btn-grounds"))==null||K.addEventListener("click",async()=>{var i,r;const n=(i=document.getElementById("grounds-doc-type"))==null?void 0:i.value,s=(r=document.getElementById("grounds-facts"))==null?void 0:r.value;if(!n||!s){I("Please select document type and enter facts.");return}await T("Analyzing facts and identifying grounds...",()=>Se(n,s))}),(J=document.getElementById("btn-summarize"))==null||J.addEventListener("click",async()=>{var s;const n=(s=document.getElementById("summary-text"))==null?void 0:s.value;if(!n){I("Please paste document text to summarize.");return}await T("Summarizing document...",()=>Ie(n))}),(W=document.getElementById("btn-explain"))==null||W.addEventListener("click",async()=>{var s;const n=(s=document.getElementById("clause-text"))==null?void 0:s.value;if(!n){I("Please paste a clause to explain.");return}await T("Analyzing clause...",()=>Ce(n))});let l="";function c(){var n;return((n=document.getElementById("output-body"))==null?void 0:n.innerText)||""}(_=document.getElementById("btn-copy"))==null||_.addEventListener("click",()=>{const n=c();navigator.clipboard.writeText(n).then(()=>{const s=document.getElementById("btn-copy");s.textContent="Copied!",setTimeout(()=>{s.textContent="Copy"},2e3)})}),(Y=document.getElementById("btn-download-txt"))==null||Y.addEventListener("click",()=>{F(c(),"txt",`nyayavedika-draft-${Date.now()}`)}),(Q=document.getElementById("btn-download-doc"))==null||Q.addEventListener("click",()=>{F(c(),"doc",`nyayavedika-draft-${Date.now()}`)}),(X=document.getElementById("btn-download-docx"))==null||X.addEventListener("click",()=>{F(c(),"doc",`nyayavedika-draft-${Date.now()}`)}),(Z=document.getElementById("btn-save-snippet"))==null||Z.addEventListener("click",()=>{const n=c();if(!n)return;const s=prompt("Snippet title:",l||"My Snippet");if(!s)return;Le({title:s,content:n,category:"Generated"});const i=document.getElementById("btn-save-snippet");i.textContent="✓ Saved",setTimeout(()=>{i.textContent="☆ Save"},2e3)}),(ee=document.getElementById("btn-clear"))==null||ee.addEventListener("click",U),(te=document.getElementById("btn-cancel"))==null||te.addEventListener("click",()=>{de(),L(),I("Request cancelled.")});function p(){const n=document.getElementById("history-list");if(!n)return;const s=H();if(s.length===0){n.innerHTML='<p class="history-empty">No drafts generated yet. Your generated documents will appear here.</p>';return}n.innerHTML=s.map(i=>`
      <div class="history-item">
        <div class="history-item-info">
          <strong>${w(i.title)}</strong>
          <span class="history-meta">${w(i.type||"Draft")} ${i.court?"· "+w(i.court):""}</span>
          <span class="history-date">${new Date(i.timestamp).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"})}</span>
        </div>
        <div class="history-item-actions">
          <button class="btn btn-outline btn-sm history-load" data-id="${i.id}">Load</button>
          <button class="btn btn-outline btn-sm history-delete" data-id="${i.id}" style="color:var(--red);border-color:rgba(239,68,68,0.2)">✕</button>
        </div>
      </div>
    `).join(""),n.querySelectorAll(".history-load").forEach(i=>{i.addEventListener("click",()=>{const r=parseInt(i.dataset.id),d=H().find(m=>m.id===r);d&&(d.content,l=d.title,G(d.content),document.getElementById("history-panel").style.display="none")})}),n.querySelectorAll(".history-delete").forEach(i=>{i.addEventListener("click",()=>{const r=parseInt(i.dataset.id);Ne(r),p()})})}(ae=document.getElementById("btn-show-history"))==null||ae.addEventListener("click",()=>{const n=document.getElementById("history-panel"),s=(n==null?void 0:n.style.display)==="block";n&&(n.style.display=s?"none":"block"),s||p();const i=document.getElementById("snippets-panel");i&&(i.style.display="none")}),(ne=document.getElementById("btn-history-close"))==null||ne.addEventListener("click",()=>{const n=document.getElementById("history-panel");n&&(n.style.display="none")});function g(){const n=document.getElementById("snippets-list");if(!n)return;const s=R();if(s.length===0){n.innerHTML='<p class="snippets-empty">No snippets saved yet. Save generated outputs or frequently used text as snippets for quick reuse.</p>';return}n.innerHTML=s.map(i=>`
      <div class="snippet-item">
        <div class="snippet-item-info">
          <strong>${w(i.title)}</strong>
          <span class="snippet-category">${w(i.category)}</span>
          <span class="snippet-preview">${w(i.content.substring(0,120))}...</span>
        </div>
        <div class="snippet-item-actions">
          <button class="btn btn-outline btn-sm snippet-insert" data-id="${i.id}" title="Insert into current draft tab">Use</button>
          <button class="btn btn-outline btn-sm snippet-delete" data-id="${i.id}" style="color:var(--red);border-color:rgba(239,68,68,0.2)">✕</button>
        </div>
      </div>
    `).join(""),n.querySelectorAll(".snippet-insert").forEach(i=>{i.addEventListener("click",()=>{const r=parseInt(i.dataset.id),d=R().find(m=>m.id===r);d&&(d.content,l=d.title,G(d.content),document.getElementById("snippets-panel").style.display="none")})}),n.querySelectorAll(".snippet-delete").forEach(i=>{i.addEventListener("click",()=>{const r=parseInt(i.dataset.id);Pe(r),g()})})}(ie=document.getElementById("btn-show-snippets"))==null||ie.addEventListener("click",()=>{const n=document.getElementById("snippets-panel"),s=(n==null?void 0:n.style.display)==="block";n&&(n.style.display=s?"none":"block"),s||g();const i=document.getElementById("history-panel");i&&(i.style.display="none")}),(se=document.getElementById("btn-snippets-close"))==null||se.addEventListener("click",()=>{const n=document.getElementById("snippets-panel");n&&(n.style.display="none")});function f(){const n=document.getElementById("favorites-bar"),s=document.getElementById("favorites-list");if(!n||!s)return;const i=q();if(i.length===0){n.style.display="none";return}n.style.display="flex",s.innerHTML=i.map(r=>`
      <button class="fav-chip" data-doctype="${w(r)}">⭐ ${w(r)}</button>
    `).join(""),s.querySelectorAll(".fav-chip").forEach(r=>{r.addEventListener("click",()=>{document.querySelectorAll(".ai-tab").forEach(S=>{S.classList.remove("active"),S.setAttribute("aria-selected","false")}),document.querySelectorAll(".ai-tab-content").forEach(S=>S.classList.remove("active"));const d=document.getElementById("tab-btn-draft");d&&(d.classList.add("active"),d.setAttribute("aria-selected","true"));const m=document.getElementById("tab-draft");m&&m.classList.add("active");const C=document.getElementById("doc-type");C&&(C.value=r.dataset.doctype)})})}f();function A(){const n=document.getElementById("tab-draft");if(!n)return;const s=document.getElementById("doc-type");if(!s)return;s.addEventListener("change",()=>{const r=s.value;if(!r)return;const d=q(),m=document.getElementById("btn-fav-toggle");m&&(m.textContent=d.includes(r)?"★ Unfavorite":"☆ Favorite")});const i=n.querySelector(".form-grid");if(i&&!document.getElementById("btn-fav-toggle")){const r=document.createElement("button");r.id="btn-fav-toggle",r.className="btn btn-outline btn-sm",r.style.cssText="margin-top:24px;",r.textContent="☆ Favorite this type",r.addEventListener("click",d=>{var S;d.preventDefault();const m=(S=document.getElementById("doc-type"))==null?void 0:S.value;if(!m)return;const C=De(m);r.textContent=C.includes(m)?"★ Unfavorite":"☆ Favorite",f()}),i.after(r)}}setTimeout(A,100),document.addEventListener("keydown",n=>{var s,i,r,d,m,C,S,oe;if(n.ctrlKey&&n.key==="Enter"){const u=document.querySelector(".ai-tab.active");(u==null?void 0:u.dataset.tab)==="ask"?o():(u==null?void 0:u.dataset.tab)==="draft"?(s=document.getElementById("btn-draft"))==null||s.click():(u==null?void 0:u.dataset.tab)==="caselaws"?(i=document.getElementById("btn-caselaws"))==null||i.click():(u==null?void 0:u.dataset.tab)==="analyze"?(r=document.getElementById("btn-analyze"))==null||r.click():(u==null?void 0:u.dataset.tab)==="grounds"?(d=document.getElementById("btn-grounds"))==null||d.click():(u==null?void 0:u.dataset.tab)==="summarize"?(m=document.getElementById("btn-summarize"))==null||m.click():(u==null?void 0:u.dataset.tab)==="explain"&&((C=document.getElementById("btn-explain"))==null||C.click())}if(n.ctrlKey&&n.key==="h"&&(n.preventDefault(),(S=document.getElementById("btn-show-history"))==null||S.click()),n.ctrlKey&&n.key==="s"&&(n.preventDefault(),(oe=document.getElementById("btn-save-snippet"))==null||oe.click()),n.key==="Escape"){const u=document.getElementById("history-panel"),P=document.getElementById("snippets-panel");(u==null?void 0:u.style.display)==="block"&&(u.style.display="none"),(P==null?void 0:P.style.display)==="block"&&(P.style.display="none")}});const b=e.querySelectorAll(".widget-tab");b.length>0&&(b.forEach(n=>{n.addEventListener("click",()=>{b.forEach(s=>s.classList.remove("active")),n.classList.add("active"),ce(n.dataset.wtab)})}),ce("Supreme Court"))}let z=null;const D={"Supreme Court":[{title:"Bail Under NDPS Act — Twin Conditions Reiterated",summary:"The Supreme Court reiterated that under Section 37 of NDPS Act, both twin conditions must be mandatorily satisfied before granting bail. The court emphasized that the bar under Section 37 is in addition to limitations under CrPC/BNSS."},{title:"Article 21 — Right to Speedy Trial",summary:"In a landmark ruling, the Supreme Court held that prolonged incarceration without trial violates Article 21 of the Constitution. The court directed all High Courts to review undertrial prisoners who have served more than half the maximum sentence."},{title:"Section 436A BNSS — Default Bail Guidelines",summary:"The Supreme Court issued comprehensive guidelines on default bail under Section 187 BNSS (formerly Section 167 CrPC), clarifying that the right to default bail is an indefeasible right that cannot be taken away even if the chargesheet is filed belatedly."},{title:"Arbitration — Party Autonomy in Appointment",summary:"The Court upheld the principle of party autonomy in arbitration, ruling that courts should adopt a hands-off approach in the appointment of arbitrators when parties have agreed to an institutional mechanism."},{title:"Consumer Protection — E-Commerce Liability",summary:"The Supreme Court clarified the liability of e-commerce platforms under the Consumer Protection Act, 2019, holding that platforms that exercise significant control over transactions cannot claim mere intermediary status."}],"High Court":[{title:"Quashing Under Section 528 BNSS — Scope Clarified",summary:"The High Court reiterated that inherent powers under Section 528 BNSS (formerly Section 482 CrPC) should be exercised sparingly and only when the charge is manifestly absurd or the proceedings are clearly vexatious."},{title:"Writ Petition — Alternative Remedy Not a Bar",summary:"The High Court held that the availability of an alternative remedy does not bar a writ petition under Article 226 when fundamental rights are directly involved or when the impugned order is patently illegal."},{title:"Land Revenue — Mutation Not Conferring Title",summary:"The High Court clarified that mutation entries in revenue records do not confer title and are merely fiscal in nature. Disputes regarding ownership must be resolved through civil proceedings."},{title:"Anticipatory Bail — Custodial Interrogation Not Always Necessary",summary:"The High Court granted anticipatory bail holding that custodial interrogation is not necessary in every case, especially when the accused has cooperated with the investigation and there is no flight risk."},{title:"Domestic Violence Act — Right of Residence",summary:"The High Court upheld the right of residence under Section 17 of the DV Act, ruling that a woman in a domestic relationship cannot be evicted from the shared household without due process of law."}],Tribunals:[{title:"NCLT — CIRP Timeline Extension",summary:"The NCLT addressed the issue of CIRP timeline extensions under IBC, reiterating that the 330-day deadline is mandatory and extensions can only be granted in exceptional circumstances with valid reasons documented."},{title:"ITAT — Capital Gains Exemption Under Section 54",summary:"The ITAT held that the exemption under Section 54 of the Income Tax Act for capital gains on sale of residential property is available even when the new property is purchased in the name of the spouse, subject to certain conditions."},{title:"NGT — Environmental Clearance Compliance",summary:"The National Green Tribunal imposed heavy penalties on industries operating without proper environmental clearances, directing immediate cessation of operations until compliance is demonstrated."},{title:"CAT — Compassionate Appointment Guidelines",summary:"The Central Administrative Tribunal reiterated that compassionate appointment is not a vested right but should be considered sympathetically when the family is in dire financial distress following the death of a government servant."},{title:"NCDRC — Medical Negligence Standards",summary:"The NCDRC held that for establishing medical negligence, the complainant must prove that the doctor did not exercise the standard of care expected from a reasonably competent practitioner in that field."}]};async function ce(e){const t=document.getElementById("widget-loading"),a=document.getElementById("widget-feed"),o=document.getElementById("widget-error");if(!t||!a)return;z&&z.abort(),z=new AbortController,t.style.display="flex",a.style.display="none",o.style.display="none";function l(c){a.innerHTML=c.map(p=>`
      <div class="news-card">
        <h4>${w(p.title)}</h4>
        <p>${w(p.summary)}</p>
      </div>
    `).join(""),t.style.display="none",a.style.display="flex"}try{const p=(await Te(e)).split("|||").map(g=>g.trim()).filter(Boolean).map(g=>{const f=g.split(`
`);return{title:f[0]||"Legal Update",summary:f.slice(1).join(" ").trim()||""}});p.length>0?l(p):l(D[e]||D["Supreme Court"])}catch(c){c.name!=="AbortError"&&l(D[e]||D["Supreme Court"])}}async function T(e,t,a=null){V(),U(),he(e);try{const o=await t();L(),G(o),lastGeneratedContent=o,lastGeneratedTitle=(a==null?void 0:a.title)||"Generated Draft",o&&Be({title:(a==null?void 0:a.title)||"AI Generated Draft",type:(a==null?void 0:a.type)||"",court:(a==null?void 0:a.court)||"",content:o})}catch(o){L(),I(o.message)}}function he(e){const t=document.getElementById("ai-loading"),a=document.getElementById("loading-text");t&&(t.style.display="flex"),a&&(a.textContent=e),j("loading","Generating...")}function L(){const e=document.getElementById("ai-loading");e&&(e.style.display="none"),j("ready","Ready")}function G(e){const t=document.getElementById("ai-output"),a=document.getElementById("output-body");!t||!a||(a.textContent=e,t.style.display="block")}function U(){const e=document.getElementById("ai-output");e&&(e.style.display="none")}function I(e){const t=document.getElementById("ai-error"),a=document.getElementById("error-text");t&&(t.style.display="flex"),a&&(a.textContent=e),j("error","Error")}function V(){const e=document.getElementById("ai-error");e&&(e.style.display="none")}function j(e,t){const a=document.getElementById("ai-status-indicator");if(!a)return;const o=e.replace(/[^a-z]/g,"");a.className=`ai-status status-${o}`,a.textContent="";const l=document.createElement("span");l.className="status-dot",a.appendChild(l),a.appendChild(document.createTextNode(` ${t}`))}function Ue(){return`
  <section class="hero reveal visible" id="hero">
    <div class="hero-inner">
      <span class="hero-badge">Free for All Indian Advocates — No Subscription Required</span>
      <h1 class="hero-title">AI-Powered Legal Drafting<br><span class="gradient-text">for Supreme Court, High Court & District Courts</span></h1>
      <p class="hero-sub">An indispensable AI drafting tool for Indian legal professionals. Generate court-ready SLPs, writ petitions, bail applications, NDPS bail, revenue appeals — in minutes, not hours.</p>
      <div class="hero-cta">
        <a href="#drafting" class="btn btn-primary" id="cta-start">Start Drafting — Free</a>
        <a href="#how-it-works" class="btn btn-outline" id="cta-how">See how it works</a>
      </div>
    </div>
  </section>

  <section class="trust-row reveal" id="trust-stats">
    <div class="container">
      <div class="trust-grid">
        <div class="trust-item reveal reveal-delay-1">
          <span class="trust-value">15+</span>
          <span class="trust-label">Document Types</span>
        </div>
        <div class="trust-item reveal reveal-delay-2">
          <span class="trust-value">&lt; 3 min</span>
          <span class="trust-label">Average Draft Time</span>
        </div>
        <div class="trust-item reveal reveal-delay-3">
          <span class="trust-value">SC • HC • DC</span>
          <span class="trust-label">All Court Levels</span>
        </div>
        <div class="trust-item reveal reveal-delay-4">
          <span class="trust-value">100%</span>
          <span class="trust-label">Free — No Paywall</span>
        </div>
      </div>
    </div>
  </section>

  <section class="features reveal" id="features">
    <div class="container">
      <h2 class="section-title">Everything an advocate needs — from Supreme Court to Tahsildar</h2>
      <p class="section-sub">AI-assisted legal research, drafting, and document analysis. Built for the way Indian advocates actually practice.</p>
      <div class="feature-grid feature-grid-6">
        <div class="feature-card reveal reveal-delay-1" id="feat-ask">
          <div class="feature-icon">
            <svg viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M8 8h24v20H18l-6 6v-6H8V8z" stroke-linejoin="round"/><line x1="14" y1="16" x2="26" y2="16"/><line x1="14" y1="21" x2="22" y2="21"/></svg>
          </div>
          <h3>Ask a Question</h3>
          <p>Chat with AI about any legal topic — get detailed answers with relevant statutes, case law, and practical guidance.</p>
        </div>
        <div class="feature-card reveal reveal-delay-2" id="feat-drafting">
          <div class="feature-icon">
            <svg viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="6" y="4" width="28" height="32" rx="3"/><line x1="12" y1="12" x2="28" y2="12"/><line x1="12" y1="18" x2="28" y2="18"/><line x1="12" y1="24" x2="22" y2="24"/><path d="M26 28l4-4-4-4" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </div>
          <h3>Draft Documents & Legal Notices</h3>
          <p>Generate 25+ document types — SLPs, writs, bail, legal notices, written submissions, PIL, consumer complaints — all courts covered.</p>
        </div>
        <div class="feature-card reveal reveal-delay-3" id="feat-caselaws">
          <div class="feature-icon">
            <svg viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="18" cy="18" r="10"/><line x1="25" y1="25" x2="34" y2="34" stroke-linecap="round"/><line x1="14" y1="14" x2="22" y2="14"/><line x1="14" y1="18" x2="22" y2="18"/><line x1="14" y1="22" x2="18" y2="22"/></svg>
          </div>
          <h3>Find Case Laws</h3>
          <p>Enter your legal issue — AI finds relevant Supreme Court & High Court precedents with citations and legal principles.</p>
        </div>
        <div class="feature-card reveal reveal-delay-4" id="feat-analyze">
          <div class="feature-icon">
            <svg viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="4" y="6" width="20" height="28" rx="2"/><path d="M28 12h6v22a2 2 0 01-2 2H10"/><circle cx="14" cy="20" r="4"/><line x1="10" y1="28" x2="18" y2="28"/></svg>
          </div>
          <h3>Analyze Case / Chargesheet</h3>
          <p>Upload any FIR, chargesheet, judgment, or court order — AI extracts parties, issues, applicable law, and strategic notes.</p>
        </div>
        <div class="feature-card reveal reveal-delay-1" id="feat-submissions">
          <div class="feature-icon">
            <svg viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="8" y="4" width="24" height="32" rx="2"/><line x1="14" y1="12" x2="26" y2="12"/><line x1="14" y1="17" x2="26" y2="17"/><line x1="14" y1="22" x2="26" y2="22"/><line x1="14" y1="27" x2="20" y2="27"/><path d="M4 8v28h28" stroke-dasharray="3 3"/></svg>
          </div>
          <h3>Write Submissions</h3>
          <p>AI drafts comprehensive written arguments with statutory citations, case law, and proper Indian court format.</p>
        </div>
        <div class="feature-card reveal reveal-delay-2" id="feat-summarize">
          <div class="feature-icon">
            <svg viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 6h28v28H6z" rx="3"/><line x1="12" y1="14" x2="28" y2="14"/><line x1="12" y1="20" x2="24" y2="20"/><line x1="12" y1="26" x2="20" y2="26"/><circle cx="8" cy="14" r="1" fill="currentColor"/><circle cx="8" cy="20" r="1" fill="currentColor"/><circle cx="8" cy="26" r="1" fill="currentColor"/></svg>
          </div>
          <h3>Summarize & Explain</h3>
          <p>Summarize Supreme Court & High Court judgments, extract key orders, and explain complex clauses in plain English.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="workflow-preview reveal" id="workflow-preview">
    <div class="container">
      <h2 class="section-title">See the workflow in action</h2>
      <div class="preview-box">
        <div class="preview-steps">
          <div class="preview-step active" data-step="1">
            <span class="step-num">1</span>
            <span>Upload case files</span>
          </div>
          <div class="preview-step" data-step="2">
            <span class="step-num">2</span>
            <span>Describe relief sought</span>
          </div>
          <div class="preview-step" data-step="3">
            <span class="step-num">3</span>
            <span>AI generates draft</span>
          </div>
          <div class="preview-step" data-step="4">
            <span class="step-num">4</span>
            <span>Download DOCX</span>
          </div>
        </div>
        <div class="preview-screen">
          <div class="screen-mock">
            <div class="screen-toolbar">
              <span class="dot red"></span><span class="dot yellow"></span><span class="dot green"></span>
              <span class="screen-url">app.nyayavedika.in</span>
            </div>
            <div class="screen-body">
              <div class="mock-sidebar">
                <div class="mock-item active"></div>
                <div class="mock-item"></div>
                <div class="mock-item"></div>
              </div>
              <div class="mock-content">
                <div class="mock-line w80"></div>
                <div class="mock-line w60"></div>
                <div class="mock-line w90"></div>
                <div class="mock-line w40"></div>
                <div class="mock-line w70"></div>
                <div class="mock-line w50"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="cta-bottom reveal" id="cta-bottom">
    <div class="container">
      <h2>Start drafting like a top-tier chamber — for free</h2>
      <p>No subscriptions. No paywalls. Just powerful AI drafting for every Indian advocate, from solo practitioners to large firms.</p>
      <a href="#drafting" class="btn btn-primary btn-lg">Open AI Drafting Tool — Free</a>
    </div>
  </section>`}function Ve(){return`
  <section class="page-hero reveal visible" id="drafting-hero">
    <div class="container">
      <h1 class="page-hero-title">AI Drafting Assistant</h1>
      <p class="page-hero-sub">Generate court-ready petitions for Supreme Court, High Court & District Courts. Analyze judgments, explore legal grounds, and draft in minutes — free for all advocates.</p>
    </div>
  </section>
  <div class="container">
    <div id="ai-panel-mount"></div>
  </div>
  <section class="disclaimer-banner" id="drafting-disclaimer">
    <div class="container">
      <p><strong>⚠️ Important:</strong> All drafts must be reviewed and finalized by a qualified advocate before filing. NyayaVedika is a drafting tool, not legal advice.</p>
    </div>
  </section>`}function je(){const e=[{num:"01",title:"Select Document Type & Court",desc:"Choose from 15+ document types — SLPs, writ petitions, bail applications (including NDPS bail), revenue appeals, quashing petitions, and more. Select the specific court or authority for proper formatting.",icon:"📋"},{num:"02",title:"Enter Case Facts & Relief",desc:"Describe your client's situation — FIR details, impugned orders, land records, previous court orders. Specify the relief sought. The AI understands BNS, BNSS, IPC, CrPC, and special acts.",icon:"⚖️"},{num:"03",title:"AI Generates Court-Ready Draft",desc:"NyayaVedika generates a structured, statute-compliant draft with proper cause title, synopsis, numbered grounds with citations, prayer clause, and verification — in under 3 minutes.",icon:"🤖"},{num:"04",title:"Copy, Download & File",desc:"Copy to clipboard or download as a text file. Review the draft, make any modifications, and file with confidence. The AI drafts — you retain full professional control.",icon:"📥"}];return`
  <section class="page-hero reveal visible" id="hiw-hero">
    <div class="container">
      <h1 class="page-hero-title">How It Works</h1>
      <p class="page-hero-sub">Four simple steps from case files to court-ready draft.</p>
    </div>
  </section>

  <section class="steps-section reveal" id="steps">
    <div class="container">
      <div class="steps-timeline">
        ${e.map((t,a)=>`
          <div class="step-card" id="step-${t.num}" style="--delay: ${a*.1}s">
            <div class="step-left">
              <span class="step-number">${t.num}</span>
              <div class="step-line${a===e.length-1?" last":""}"></div>
            </div>
            <div class="step-right">
              <span class="step-icon">${t.icon}</span>
              <h3>${t.title}</h3>
              <p>${t.desc}</p>
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  </section>

  <section class="disclaimer-banner" id="hiw-disclaimer">
    <div class="container">
      <p><strong>⚠️ Important:</strong> All drafts must be reviewed and finalized by a qualified advocate. NyayaVedika is a tool, not a law firm.</p>
    </div>
  </section>`}function Me(){return`
  <section class="page-hero reveal visible" id="adv-hero">
    <div class="container">
      <h1 class="page-hero-title">Built for Advocates</h1>
      <p class="page-hero-sub">Whether you practice alone or lead a team — NyayaVedika fits your workflow.</p>
    </div>
  </section>

  <section class="segments reveal" id="segments">
    <div class="container">
      ${[{id:"solo",title:"Solo Practitioners",desc:"You handle everything — research, drafting, filing, court appearances. NyayaVedika gives you the drafting capacity of a junior without the overhead. All features free, no subscription.",cases:["Bail & anticipatory bail for District & Sessions Courts","NDPS bail applications with Section 37 twin conditions","Writ petitions under Article 226 before High Court","Revenue appeals (ROR mutations, land disputes, 1-B proceedings)","Default bail under Section 187 BNSS / 167 CrPC","Cheque bounce complaints under NI Act Section 138"]},{id:"chambers",title:"Chambers & Associates",desc:"Your chambers handles a steady volume of cases. NyayaVedika lets your team produce consistent, well-structured drafts in a fraction of the time.",cases:["Standardize brief formats across associates","Handle multiple criminal revisions in parallel","Quick turnaround on bail and remand applications","Quashing petitions under Section 528 BNSS / 482 CrPC","Interlocutory Applications (IAs) and caveat petitions","Consumer disputes before NCDRC and State Commission"]},{id:"firms",title:"Law Firms",desc:"For firms handling high-volume Supreme Court and High Court litigation. NyayaVedika produces court-ready drafts following SC Rules 2013 and HC Original Side Rules.",cases:["SLPs before the Supreme Court under Article 136","Writ petitions under Article 32 for fundamental rights","Multi-party property and partition suits","Contempt petitions under Contempt of Courts Act","Batch drafting for similar case types across courts","SC/ST Act cases and NDPS special bail procedures"]}].map((t,a)=>`
        <div class="segment-card reveal reveal-delay-${a+1}" id="seg-${t.id}">
          <div class="segment-header">
            <h2>${t.title}</h2>
            <p>${t.desc}</p>
          </div>
          <ul class="segment-list">
            ${t.cases.map(o=>`<li>${o}</li>`).join("")}
          </ul>
        </div>
      `).join("")}
    </div>
  </section>`}function Ke(){return`
  <section class="page-hero reveal visible" id="security-hero">
    <div class="container">
      <h1 class="page-hero-title">Security & Legal</h1>
      <p class="page-hero-sub">How we handle your data, and what to know before using NyayaVedika.</p>
    </div>
  </section>

  <section class="security-section reveal" id="security-content">
    <div class="container">
      <div class="security-grid">
        <div class="security-card reveal reveal-delay-1" id="sec-encryption">
          <div class="security-icon">🔒</div>
          <h3>Encryption at Rest & in Transit</h3>
          <p>All data is encrypted using AES-256 at rest and TLS 1.3 in transit. Your case files and drafts are protected at every stage.</p>
        </div>
        <div class="security-card reveal reveal-delay-2" id="sec-retention">
          <div class="security-icon">🗑️</div>
          <h3>Minimal Data Retention</h3>
          <p>Uploaded documents are processed and not retained beyond your active session unless you explicitly save them to your account. You control your data.</p>
        </div>
        <div class="security-card reveal reveal-delay-3" id="sec-access">
          <div class="security-icon">🛡️</div>
          <h3>Access Controls</h3>
          <p>Role-based access for team accounts. Only authorized members of your chambers or firm can view or edit shared drafts.</p>
        </div>
        <div class="security-card reveal reveal-delay-4" id="sec-compliance">
          <div class="security-icon">📋</div>
          <h3>Compliance Ready</h3>
          <p>Built with Indian data protection considerations in mind. We are actively working toward compliance with applicable regulations.</p>
        </div>
      </div>

      <div class="legal-disclaimer" id="legal-disclaimer">
        <h2>⚖️ Legal Disclaimer</h2>
        <div class="disclaimer-content">
          <p><strong>NyayaVedika is an AI-assisted drafting tool, not a law firm and not a substitute for qualified legal counsel.</strong></p>
          <ul>
            <li>All drafts generated by NyayaVedika must be reviewed, verified, and finalized by a qualified advocate before submission to any court or authority.</li>
            <li>NyayaVedika provides <strong>high statutory coverage with AI assistance</strong>. The platform does not guarantee the accuracy, completeness, or legal sufficiency of any generated document.</li>
            <li>No attorney-client relationship is created by using NyayaVedika.</li>
            <li>Past results, sample outputs, or demonstrated capabilities do not guarantee similar outcomes in your specific case.</li>
            <li>The advocate using NyayaVedika bears full professional responsibility for all documents filed with courts or authorities.</li>
          </ul>
          <p class="disclaimer-final">By using NyayaVedika, you acknowledge that you are a qualified legal professional and accept these terms.</p>
        </div>
      </div>
    </div>
  </section>`}function Je(){return`
  <section class="page-hero reveal visible" id="legal-updates-hero">
    <div class="container">
      <h1 class="page-hero-title">📰 Legal Updates & Digest</h1>
      <p class="page-hero-sub">Enter any legal topic — get a comprehensive AI-generated digest with statutes, landmark judgments, recent developments, and practice tips.</p>
    </div>
  </section>

  <section class="legal-updates-section reveal" id="legal-updates-content">
    <div class="container">
      <div class="legal-updates-input-area">
        <div class="form-group">
          <label class="form-label" for="legal-topic-input">Enter Legal Topic</label>
          <input class="form-input form-input-lg" id="legal-topic-input" placeholder="e.g. Section 37 NDPS Act twin conditions for bail, Article 226 vs 227 differences..." />
        </div>
        <button class="btn btn-primary btn-lg" id="btn-generate-update">
          <span class="btn-icon">🔍</span> Generate Legal Digest
        </button>
      </div>

      <div class="popular-topics">
        <h3>Popular Topics</h3>
        <div class="topics-grid">
          ${["Section 37 NDPS Act — Twin Conditions for Bail","Article 226 vs 227 — High Court Powers","Default Bail under Section 187 BNSS","Quashing under Section 528 BNSS / 482 CrPC","Anticipatory Bail under BNS/BNSS","Consumer Protection Act 2019 — Key Changes","IBC — CIRP Process and Timelines","Cheque Bounce — NI Act Section 138 Procedure","DV Act — Protection Orders and Remedies","Article 21 — Right to Life and Bail Jurisprudence","Land Revenue Appeals — AP & Telangana Procedure","Contempt of Courts Act — Civil vs Criminal Contempt"].map(t=>`<button class="topic-chip" data-topic="${t}">${t}</button>`).join("")}
        </div>
      </div>

      <div class="legal-update-loading" id="update-loading" style="display:none">
        <div class="loading-spinner"></div>
        <p>Generating legal digest...</p>
      </div>

      <div class="legal-update-result" id="update-result" style="display:none">
        <div class="update-result-header">
          <h3 id="update-result-title"></h3>
          <div class="output-actions">
            <button class="btn btn-outline btn-sm" id="btn-update-copy">Copy</button>
            <button class="btn btn-outline btn-sm" id="btn-update-download">Download .txt</button>
          </div>
        </div>
        <div class="update-result-body" id="update-result-body"></div>
      </div>

      <div class="ai-error" id="update-error" style="display:none">
        <span class="error-icon">⚠️</span>
        <p class="error-text" id="update-error-text"></p>
      </div>
    </div>
  </section>

  <section class="disclaimer-banner" id="updates-disclaimer">
    <div class="container">
      <p><strong>⚠️ AI-Generated Content:</strong> Legal updates are generated by AI and may not reflect the most recent developments. Always verify with primary sources before relying on this information.</p>
    </div>
  </section>`}function We(){var A,b;const e=document.getElementById("legal-topic-input"),t=document.getElementById("btn-generate-update"),a=document.getElementById("update-loading"),o=document.getElementById("update-result"),l=document.getElementById("update-result-title"),c=document.getElementById("update-result-body"),p=document.getElementById("update-error"),g=document.getElementById("update-error-text");async function f(v){if(!v){p.style.display="flex",g.textContent="Please enter a legal topic.";return}p.style.display="none",o.style.display="none",a.style.display="flex";try{const h=await ke(v);a.style.display="none",l.textContent=`Legal Digest: ${v}`,c.textContent=h,o.style.display="block"}catch(h){a.style.display="none",p.style.display="flex",g.textContent=h.message}}t==null||t.addEventListener("click",()=>f(e==null?void 0:e.value)),document.querySelectorAll(".topic-chip").forEach(v=>{v.addEventListener("click",()=>{e.value=v.dataset.topic,f(v.dataset.topic)})}),(A=document.getElementById("btn-update-copy"))==null||A.addEventListener("click",()=>{const v=c==null?void 0:c.innerText;navigator.clipboard.writeText(v).then(()=>{const h=document.getElementById("btn-update-copy");h.textContent="Copied!",setTimeout(()=>{h.textContent="Copy"},2e3)})}),(b=document.getElementById("btn-update-download"))==null||b.addEventListener("click",()=>{const v=c==null?void 0:c.innerText,h=new Blob([v],{type:"text/plain"}),N=URL.createObjectURL(h),k=document.createElement("a");k.href=N,k.download=`nyayavedika-legal-digest-${Date.now()}.txt`,k.click(),setTimeout(()=>URL.revokeObjectURL(N),1e3)})}function _e(e){return`
  <nav class="nav" id="main-nav" role="navigation" aria-label="Main navigation">
    <div class="nav-inner">
      <a href="#" class="nav-logo" id="nav-logo" aria-label="NyayaVedika home">
        <span class="nav-logo-mark">◈</span>
        <span class="nav-logo-text">NyayaVedika</span>
      </a>
      <button class="nav-toggle" id="nav-toggle" aria-label="Toggle menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
      <div class="nav-links" id="nav-links">
        ${[{hash:"",label:"Home"},{hash:"drafting",label:"⚡ AI Drafting"},{hash:"legal-updates",label:"📰 Legal Updates"},{hash:"how-it-works",label:"How It Works"},{hash:"for-advocates",label:"For Advocates"},{hash:"security",label:"Security & Legal"}].map(a=>`
          <a href="#${a.hash}" class="nav-link${e===a.hash?" active":""}${e===a.hash?'" aria-current="page':""}" id="nav-${a.hash||"home"}">${a.label}</a>
        `).join("")}
      </div>
      <button class="theme-toggle" id="theme-toggle" aria-label="Toggle theme" title="Toggle dark/light theme">
        <span class="theme-icon-dark">🌙</span>
        <span class="theme-icon-light">☀️</span>
      </button>
      <a href="#drafting" class="btn btn-primary btn-sm nav-cta" id="nav-cta">Get Started</a>
    </div>
  </nav>`}function Ye(){return`
  <footer class="footer" id="footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <span class="nav-logo-mark">◈</span>
          <span class="nav-logo-text">NyayaVedika</span>
          <p class="footer-tagline">AI-powered legal drafting for Indian advocates.</p>
        </div>
        <div class="footer-col">
          <h4>Product</h4>
          <a href="#drafting">AI Drafting</a>
          <a href="#legal-updates">Legal Updates</a>
          <a href="#how-it-works">How It Works</a>
          <a href="#for-advocates">For Advocates</a>
        </div>
        <div class="footer-col">
          <h4>Use Cases</h4>
          <a href="#for-advocates">Solo Practitioners</a>
          <a href="#for-advocates">Chambers</a>
          <a href="#for-advocates">Law Firms</a>
        </div>
        <div class="footer-col">
          <h4>Legal</h4>
          <a href="#security">Disclaimer</a>
          <a href="#security">Privacy Policy</a>
          <a href="#security">Terms of Use</a>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2026 NyayaVedika. All rights reserved.</p>
        <p class="footer-disclaimer">NyayaVedika is a drafting tool. All outputs must be reviewed by a qualified advocate.</p>
      </div>
    </div>
  </footer>`}const ye={"":Ue,drafting:Ve,"legal-updates":Je,"how-it-works":je,"for-advocates":Me,security:Ke};function Qe(){const e=window.location.hash.replace("#","");return ye[e]?e:""}function Xe(){const e=new IntersectionObserver(t=>{t.forEach(a=>{a.isIntersecting&&a.target.classList.add("visible")})},{threshold:.15,rootMargin:"0px 0px -40px 0px"});document.querySelectorAll(".reveal").forEach(t=>e.observe(t))}function Ze(){document.querySelectorAll(".feature-card").forEach(e=>{e.addEventListener("mousemove",t=>{const a=e.getBoundingClientRect();e.style.setProperty("--mouse-x",`${(t.clientX-a.left)/a.width*100}%`),e.style.setProperty("--mouse-y",`${(t.clientY-a.top)/a.height*100}%`)})})}function ge(){var a;const e=Qe(),t=document.getElementById("app");t.innerHTML=_e(e)+ye[e]()+Ye(),e==="drafting"&&ze("ai-panel-mount"),e==="legal-updates"&&We(),Xe(),Ze(),(a=document.getElementById("theme-toggle"))==null||a.addEventListener("click",()=>{const o=pe();$(o)}),$(O()),window.scrollTo({top:0,behavior:"smooth"})}function et(){document.addEventListener("click",e=>{if(e.target.closest(".nav-link")){const a=document.getElementById("nav-links"),o=document.getElementById("nav-toggle");a==null||a.classList.remove("open"),o==null||o.classList.remove("open"),o==null||o.setAttribute("aria-expanded","false")}if(e.target.closest("#nav-toggle")){const a=document.getElementById("nav-links"),o=document.getElementById("nav-toggle"),l=a==null?void 0:a.classList.toggle("open");o==null||o.classList.toggle("open"),o==null||o.setAttribute("aria-expanded",String(l))}})}function tt(){var e;ue(O()),(e=document.getElementById("theme-toggle"))==null||e.addEventListener("click",()=>{const t=pe();$(t)})}function $(e){const t=document.querySelector(".theme-icon-dark"),a=document.querySelector(".theme-icon-light");!t||!a||(t.style.display=e==="dark"?"none":"inline",a.style.display=e==="dark"?"inline":"none")}window.addEventListener("hashchange",ge);et();tt();ge();$(O());
